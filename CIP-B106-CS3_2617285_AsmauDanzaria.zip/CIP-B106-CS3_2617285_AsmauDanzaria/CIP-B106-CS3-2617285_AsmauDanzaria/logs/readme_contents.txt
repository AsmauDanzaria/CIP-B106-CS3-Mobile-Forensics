/home/kali/CIP-B106-CS3-2617285_AsmauDanzaria/evidence_working/disk_images/disk_images/readme.txt
----- /home/kali/CIP-B106-CS3-2617285_AsmauDanzaria/evidence_working/disk_images/disk_images/readme.txt -----
Links are included in the PPTs